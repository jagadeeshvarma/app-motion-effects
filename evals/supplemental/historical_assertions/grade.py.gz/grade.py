#!/usr/bin/env python3
import argparse,hashlib,json,re,subprocess
from pathlib import Path
base=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--scenario',choices=['M','N'],required=True);p.add_argument('--workspace',required=True);p.add_argument('--transcript');p.add_argument('--prior-workspace');p.add_argument('--timeout',type=int,default=90);args=p.parse_args()
spec=next(case for case in json.loads((base/'scenarios.json').read_text())['cases'] if case['id']==args.scenario)
original=base/spec['fixture'];output=Path(args.workspace).resolve();checks=[];blockers=[]
def check(id,passed,detail=None):
 item={'id':id,'pass':bool(passed)}
 if detail:item['detail']=detail
 checks.append(item)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
protected=[p for p in original.rglob('*') if p.is_file() and p.name in {'AGENTS.md','model.js','receipts.js'}]
damaged=[str(p.relative_to(original)) for p in protected if sha(p)!=sha(output/p.relative_to(original))]
check('protected-local-contracts',not damaged,', '.join(damaged) or None)
new_deps=[str(p.relative_to(output)) for p in output.rglob('*') if p.is_file() and p.name in {'package.json','package-lock.json','pnpm-lock.yaml','yarn.lock','pubspec.yaml'}]
check('dependency-free',not new_deps)
public=output/spec['app_root'];sources=[p for p in public.rglob('*') if p.is_file() and p.suffix in {'.html','.css','.js'}] if public.exists() else []
text='\n'.join(p.read_text(errors='replace') for p in sources)
check('local-only',not re.search(r'\b(?:fetch|XMLHttpRequest|WebSocket)\s*\(|<(?:script|link)\b[^>]+(?:src|href)=[\"\']https?://',text))
review=output/'REVIEW.md';check('evidence-record',review.is_file() and review.stat().st_size>15)
try:
 result=subprocess.run(['node',str(base/'graders/web.mjs'),args.scenario,str(public)],capture_output=True,text=True,timeout=args.timeout)
 try:data=json.loads(result.stdout)
 except json.JSONDecodeError:data={'status':'blocked','reason':(result.stdout+result.stderr)[-2500:]}
 checks.extend(data.get('checks',[]))
 if data.get('status')=='blocked':blockers.append(data.get('reason','Browser unavailable'))
except (OSError,subprocess.TimeoutExpired) as error:blockers.append(str(error))
status='blocked' if blockers else 'pass' if all(c['pass'] for c in checks) else 'fail'
print(json.dumps({'scenario':args.scenario,'status':status,'checks':checks,'blockers':blockers,'manual_required':['product-fit','observed-playback','scope','accessibility','honest-state-feedback','source-and-evidence-honesty'],'limitations':['Automatic behavior checks do not establish product fit or truthful playback claims.']},indent=2))
raise SystemExit(2 if blockers else 0 if status=='pass' else 1)
